package myy803.course_mgt_app;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import myy803.course_mgt_app.entity.*;
import myy803.course_mgt_app.service.*;

@SpringBootTest
@TestPropertySource(
  locations = "classpath:application.properties")
public class TestCourseService {
	
	@Autowired 
	CourseService courseService;
	
	void testEmployeeDAOJpaImplIsNotNull() {
		Assertions.assertNotNull(courseService);
	}

	@Test
	void testFindByinstructorReturnsCourse() {
		Course course = courseService.findCoureseByidcourse(1);
		Assertions.assertNotNull(course);
		Assertions.assertEquals("zarras", course.getInstructor());
	}
	
	
	@Test
	void testUpdate() {
		Course course = courseService.findCoureseByidcourse(1);
		Assertions.assertNotNull(course);
		Assertions.assertEquals("zarras", course.getInstructor());
		course.setSyllabus("to ma8hma einai eukolo");
		courseService.save(course);// that is function off service to test
		Assertions.assertEquals("to ma8hma einai eukolo", course.getSyllabus());
		
		
	}
	
	
}
