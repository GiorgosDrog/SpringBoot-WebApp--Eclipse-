package myy803.course_mgt_app;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import myy803.course_mgt_app.entity.*;
import myy803.course_mgt_app.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

@SpringBootTest
@TestPropertySource(locations = "classpath:application.properties")
public class TestStudentRegService {

	@Autowired 
	StudentRegistrationService studentRegService;
	
	void testEmployeeDAOJpaImplIsNotNull() {
		Assertions.assertNotNull(studentRegService);
	}

	@Test
	void testFindByinstructorReturnsCourse() {
		StudentRegistration studentReg = studentRegService.findRegistrationBystudentid(40);
		Assertions.assertNotNull(studentReg);
		Assertions.assertEquals("Emma", studentReg.getName());
	}
	
	@Test
	void testUpdate() {
		StudentRegistration studentReg = studentRegService.findRegistrationBystudentid(40);// that is function off service to test
		Assertions.assertNotNull(studentReg);
		Assertions.assertEquals("Emma", studentReg.getName());
		studentReg.setName("Elenh");
		studentRegService.save(studentReg); // that is function off service to test
		Assertions.assertEquals("Elenh", studentReg.getName());
		
		
	}
	
}
