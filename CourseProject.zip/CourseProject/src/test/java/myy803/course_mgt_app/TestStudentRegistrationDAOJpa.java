package myy803.course_mgt_app;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import myy803.course_mgt_app.dao.StudentRegistrationDAO;
import myy803.course_mgt_app.entity.Course;
import myy803.course_mgt_app.entity.StudentRegistration;

@SpringBootTest
@TestPropertySource(
  locations = "classpath:application.properties")
public class TestStudentRegistrationDAOJpa {

	@Autowired
	StudentRegistrationDAO studentRegistration;
	
	@Test
	void testStudentRegistrationImplIsNotNull() {
		Assertions.assertNotNull(studentRegistration);
	}
	
	@Test
	void testFindByIdReturnsEmployee() {
		StudentRegistration StudentReg = studentRegistration.findRegistrationBystudentid(40);
		Assertions.assertNotNull(StudentReg);
		Assertions.assertEquals("Emma", StudentReg.getName());
	}
	
	@Test
	void testSaveStudentRegistration() {
		StudentRegistration studentReg = new StudentRegistration(1,"giorgos",5,50);
		studentRegistration.save(studentReg);
		//System.out.println(course);
		studentRegistration.delete(studentReg);
		Assertions.assertEquals(50, studentReg.getStudentid());
	}
	
	
	
}
