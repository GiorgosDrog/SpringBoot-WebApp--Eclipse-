package myy803.course_mgt_app;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.WebApplicationContext;
import myy803.course_mgt_app.controller.CourseAppController;
import myy803.course_mgt_app.entity.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@TestPropertySource(
  locations = "classpath:application.properties")
@AutoConfigureMockMvc
public class testController {

	
	@Autowired
    private WebApplicationContext context;
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	CourseAppController Controller;

	@BeforeEach
    public void setup() {
		mockMvc = MockMvcBuilders
          .webAppContextSetup(context)
          .build();
    }
	
	@Test
	void testEmployeeControllerIsNotNull() {
		Assertions.assertNotNull(Controller);
	}
	
	
	
	
	@WithMockUser(value = "zarras") // for ensure that the application start ok 
	@Test 
	void testListCourseZarrasReturnsPage() throws Exception {
		mockMvc.perform(get("/Course/course-list")).
		andExpect(status().isOk()).
		andExpect(model().attributeExists("courseList")).
		andExpect(view().name("Course/course-list"));	
	}
	
	
	@WithMockUser(value = "pvassil") // for ensure that the application start ok 
	@Test 
	void testListCoursePvassilReturnsPage() throws Exception {
		mockMvc.perform(get("/Course/course-list")).
		andExpect(status().isOk()).
		andExpect(model().attributeExists("courseList")).
		andExpect(view().name("Course/course-list"));	
	}
	
	void testSaveDeleteCourseReturnsPage() throws Exception {
		
	    Course course = new Course(1,"AEP","good",6,12,"zarras");
	    	    
	    MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<>();
	    multiValueMap.add("id", Integer.toString(course.getId()));
	    multiValueMap.add("name", course.getName());
	    multiValueMap.add("syllabus",course.getSyllabus());
	    multiValueMap.add("year", Integer.toString(course.getYear()));
	    multiValueMap.add("semester", Integer.toString(course.getSemester()));
	    multiValueMap.add("instructor", course.getInstructor());
	    //save
		mockMvc.perform(
				post("/Course/save").
			    params(multiValueMap)).
				andExpect(status().isFound()).
				andExpect(view().name("redirect:/Course/course-list"));	
		//delete
		mockMvc.perform(
				post("/Course/Delete").
			    params(multiValueMap)).
				andExpect(status().isFound()).
				andExpect(view().name("redirect:/Course/course-list"));	
	}
	
	@WithMockUser(value = "zarras") // for ensure that the application can access in StudentList 
	@Test
	void testshowStudentReturnsPage() throws Exception{
		mockMvc.perform(get("/Course/ShowStudentRegistration/?idcourse=1")).
		andExpect(status().isOk()).
		andExpect(model().attributeExists("studentRegs")).
		andExpect(view().name("StudentRegs/student-list"));	
	
	}
	
	@WithMockUser(value = "zarras") // for ensure that the application can access in StudentList 
	@Test
	void testAddCourseReturnsPage() throws Exception{
		mockMvc.perform(get("/Course/showFormForAddCourse")).
		andExpect(status().isOk()).
		andExpect(model().attributeExists("theCourse")).
		andExpect(view().name("Course/Course-Form"));	
	
	}
	
	@WithMockUser(value = "zarras") // for ensure that the application can addStudent 
	@Test
	void testAddStudentReturnsPage() throws Exception{
		mockMvc.perform(get("/Course/addStudent/?idcourse=1")).
		andExpect(status().isOk()).
		andExpect(model().attributeExists("theStudentReg")).
		andExpect(view().name("StudentRegs/AddStudent"));	
	
	}
	
	@WithMockUser(value = "zarras") // for ensure that the application can addGradeFor student with studentid 42 
	@Test
	void testSaveGradesReturnsPage() throws Exception{
		mockMvc.perform(get("/Course/ShowStudentRegistration/AddGrade?idcourse=1&studentid=42&name=EmmAvania")).
		andExpect(status().isOk()).
		andExpect(model().attributeExists("theStudentReg")).
		andExpect(view().name("/StudentRegs/addGrade"));	
	
	}
	
}
