package myy803.course_mgt_app;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import myy803.course_mgt_app.dao.*;
import myy803.course_mgt_app.entity.*;


@SpringBootTest
@TestPropertySource(
  locations = "classpath:application.properties")

public class TestCourseDAOJpa {

	@Autowired
	CourseDAO CourseDAO;
	
	@Test
	void testCourseDAOJpaImplIsNotNull() {
		Assertions.assertNotNull(CourseDAO);
	}
	
	@Test
	void testFindByinstructorReturnsCourse() {
		Course Course = CourseDAO.findCoureseByid(1);
		Assertions.assertNotNull(Course);
		Assertions.assertEquals("zarras", Course.getInstructor());
	}
	
	@Test
	void testSaveCourse() {
		Course course = new Course(7,"texnologia","",6,5,"zarras");
		CourseDAO.save(course);
		//System.out.println(course);
		CourseDAO.delete(course);
		Assertions.assertEquals(7, course.getId());
	}
	
	
}

