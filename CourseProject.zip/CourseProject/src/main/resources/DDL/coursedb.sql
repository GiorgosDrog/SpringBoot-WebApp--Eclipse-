CREATE DATABASE IF NOT EXISTS coursedb;
use coursedb; 

SET FOREIGN_KEY_CHECKS = 0;
drop table if exists course;
drop table if exists student_regs;
SET FOREIGN_KEY_CHECKS = 1;

create table course (
	id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(45) NOT NULL,
    syllabus VARCHAR(45),
    year INT,
    semester INT NOT NULL,
    instructor  VARCHAR(45) NOT NULL,
	PRIMARY KEY(id))
    ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

create table student_regs (
	idcourse INT NOT NULL,
    studentid INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(45) NOT NULL,
    yearofregistration INT NOT NULL,
    grade INT ,
    projectgrade INT,
    PRIMARY KEY(studentid),
	FOREIGN KEY(idcourse) REFERENCES `course` (`id`) ON DELETE CASCADE );
    
insert into course(id, name ,instructor, semester,year )values('1','AEP','zarras',6,1);    
insert into course(id, name ,instructor, semester,year )values('2','python','zarras',1,1);
insert into course(id, name , instructor,semester,year )values('3','texnologia','zarras',1,8);


insert into course(id, name ,instructor, semester,year )values('4','maths','pvassil',6,1);    
insert into course(id, name ,instructor, semester,year )values('5','physic','pvassil',1,1);
insert into course(id, name , instructor,semester,year )values('6','chemistry','pvassil',1,8);

INSERT INTO student_regs VALUES (1,44,'Leslie',6,3,0);
INSERT INTO student_regs VALUES (2,40,'Emma',8,5,8);
INSERT INTO student_regs VALUES (2,41,'Avani',3,5,6);
INSERT INTO student_regs VALUES (1,42,'EmmAvania',8,8,10);
INSERT INTO student_regs VALUES (3,45,'nikos',8,10,1);

INSERT INTO student_regs VALUES (4,46,'Dionusis',6,3,1);
INSERT INTO student_regs VALUES (5,47,'lampros',8,5,2);
INSERT INTO student_regs VALUES (6,48,'Ivoni',3,5,4);
INSERT INTO student_regs VALUES (6,49,'elenh',8,8,6);
INSERT INTO student_regs VALUES (6,50,'maria',8,10,1);



SELECT * FROM course 
