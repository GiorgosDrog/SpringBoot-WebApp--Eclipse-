package myy803.course_mgt_app.service;

import java.util.List;
import myy803.course_mgt_app.entity.Course;


public interface CourseService {

	public List<Course> findByInstructorLogin(String name);
	
	public Course findCoureseByidcourse(int id);
	
	public void update(Course theEmployee);
	
	public void save(Course theEmployee);
	
	public void delete(int theId);
	
}
