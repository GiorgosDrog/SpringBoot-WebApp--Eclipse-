package myy803.course_mgt_app.service.statics;

import myy803.course_mgt_app.entity.*;

public interface StatisticStrategy {
	public double CalculateStatistic(Course course);
}
