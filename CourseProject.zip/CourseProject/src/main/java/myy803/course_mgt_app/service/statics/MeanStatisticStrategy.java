package myy803.course_mgt_app.service.statics;

public class MeanStatisticStrategy extends TemplateStatisticStrategy{

	public MeanStatisticStrategy() {};
	
	@Override
	public double doActualCalculation() {
		System.out.println(getStats().getMean());
		return getStats().getMean();
	}

	
		
}
