package myy803.course_mgt_app.service;

import java.util.List;
import myy803.course_mgt_app.entity.StudentRegistration;

public interface StudentRegistrationService {
	
	public List<StudentRegistration> findRegistrationByidcourse(int id);
	
	public void update(StudentRegistration StudentReg);
	
	public void save(StudentRegistration StudentReg);
	
	public void delete(int theId);

	public StudentRegistration findRegistrationBystudentid(int studentid);


}
