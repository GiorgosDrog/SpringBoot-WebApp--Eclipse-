package myy803.course_mgt_app.service.statics;

import java.util.List;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

import myy803.course_mgt_app.entity.*;

public abstract class TemplateStatisticStrategy implements StatisticStrategy{
	
	private DescriptiveStatistics stats = new DescriptiveStatistics();
	private List<StudentRegistration> studentRegsList;
	
	
	@Override 
	public double CalculateStatistic(Course course) {
		
		studentRegsList = course.getListOfStudent();
		//System.out.println(studentRegsList);
		for(StudentRegistration studentReg :  studentRegsList) {
			stats.addValue(studentReg.getGrade());
		}
		return doActualCalculation();
	}
	
	
	abstract public double doActualCalculation();


	public DescriptiveStatistics getStats() {
		return stats;
	}


	public void setStats(DescriptiveStatistics stats) {
		this.stats = stats;
	}
}