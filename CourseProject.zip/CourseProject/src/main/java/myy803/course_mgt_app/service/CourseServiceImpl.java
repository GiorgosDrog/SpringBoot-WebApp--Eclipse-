package myy803.course_mgt_app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import myy803.course_mgt_app.dao.CourseDAO;
import myy803.course_mgt_app.entity.Course;
import myy803.course_mgt_app.service.statics.StatisticStrategy;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseDAO CourseRepository;
	//private List<StatisticStrategy> Statistics;
	private StatisticStrategy Statistics;
	
	public CourseServiceImpl() {
		super();
	}

	@Autowired
	public CourseServiceImpl(CourseDAO theCourseRepository) {
		CourseRepository = theCourseRepository;
	}
	
	
	@Override
	@Transactional
	public List<Course> findByInstructorLogin(String name) {
		List<Course> result = CourseRepository.findCourseByinstructor(name);
				
		if (result != null ) {
			return result;
		}
		else {
			// we didn't find the employee
			throw new RuntimeException("Did not find Instructor");
		}
	}

	@Override
	@Transactional
	public void save(Course theCourse) {
		CourseRepository.save(theCourse);
	}

	@Override
	@Transactional
	public void delete(int theId) {
		CourseRepository.deleteById(theId);
	}


	@Override
	@Transactional
	public void update(Course theCourse) {
		CourseRepository.save(theCourse);	
	}

	@Override
	public Course findCoureseByidcourse(int id) {
		//System.out.println(getCourseStatistics(id));
		return CourseRepository.findCoureseByid(id);
		
	}
	
	
	public double getCourseStatistics(int id) { // must return has-map String = name of course , double = statistic 		
		return getStatistics().CalculateStatistic(CourseRepository.findCoureseByid(id));
		
		}

	public StatisticStrategy getStatistics() {
		return Statistics;
	}

	public void setStatistics(StatisticStrategy statistics) {
		Statistics = statistics;
	}

}






