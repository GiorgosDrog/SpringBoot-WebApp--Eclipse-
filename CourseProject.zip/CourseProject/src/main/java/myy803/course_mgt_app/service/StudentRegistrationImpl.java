package myy803.course_mgt_app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import myy803.course_mgt_app.dao.StudentRegistrationDAO;
import myy803.course_mgt_app.dao.CourseDAO;
import myy803.course_mgt_app.entity.*;

@Service
public class StudentRegistrationImpl implements StudentRegistrationService{

	@Autowired
	private StudentRegistrationDAO StudenRegRepository;
	private CourseDAO CourseRepository;
	
	public StudentRegistrationImpl() {
		super();
	}
	
	@Autowired
	public StudentRegistrationImpl(StudentRegistrationDAO theStudentRegistrationDAO,CourseDAO courseRepository){
		StudenRegRepository = theStudentRegistrationDAO;
		CourseRepository=courseRepository;
	}
	
	@Override
	@Transactional
	public List<StudentRegistration> findRegistrationByidcourse(int id) {
		List<StudentRegistration> result = StudenRegRepository.findRegistrationByidcourse(id);
		// result list of registrations
		setListOfStudent(result,id);
		if (result != null ) {
			return result;
		}
		else {
			// we didn't find the employee
			throw new RuntimeException("Did not find REG");
		}
		
	}

	private void setListOfStudent(List<StudentRegistration> result,int id) {
		if(result !=null) {
			Course theCourse = CourseRepository.findCoureseByid(id);
			//System.out.println(result);
			theCourse.setListOfStudent(result); //by this entity "theCourse" has to calculate the Mean Value of grades  
		}

	}

	@Override
	@Transactional
	public void update(StudentRegistration StudentReg) {
		StudenRegRepository.save(StudentReg);
	}

	@Override
	@Transactional
	public void save(StudentRegistration StudentReg) {
		StudenRegRepository.save(StudentReg);
	}

	@Override
	@Transactional
	public void delete(int theId) {
		StudenRegRepository.deleteById(theId);
		
	}

	@Override
	public StudentRegistration findRegistrationBystudentid(int studentid) {
		return StudenRegRepository.findRegistrationBystudentid(studentid);
	}

}
