package myy803.course_mgt_app.controller;

//import courseproject.entity.Course;
//import courseproject.entity.studentRegistration;
//import courseproject.service.CourseService;
//import courseproject.service.StudentRegistrationService;
import myy803.course_mgt_app.entity.Course;
import myy803.course_mgt_app.service.CourseService;

import myy803.course_mgt_app.entity.StudentRegistration;
import myy803.course_mgt_app.service.StudentRegistrationService;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import java.util.List;


@Controller
@RequestMapping("/Course")
public class CourseAppController{
	
	@Autowired
	private CourseService CourseService;
	
	@Autowired
	private StudentRegistrationService studentRegService; 
	
	
	public CourseAppController(CourseService theCourseService ,StudentRegistrationService theStudentRegService ) {
		CourseService = theCourseService;
		studentRegService = theStudentRegService;
	}
	
	@RequestMapping("/course-list")
	public String listCourse(Model theModel) { // exw kanei logIn san ka8igiths ara 8elw thn lista twn ma8hmatwn tou ka8hghth 
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName(); // holds the name of logIn 
		
		List<Course> courseList = CourseService.findByInstructorLogin(currentPrincipalName); // prepei na parei san orisma to name tou ka8hghth
		//System.out.println(courseList);
		
		theModel.addAttribute("courseList", courseList);
		
		return "Course/course-list";
	}
	
	
	@RequestMapping("/ShowStudentRegistration") //for one specific course give me the studentsReg 
	public String ShowStudentReg(@RequestParam("idcourse") int theId , Model theModel) {
		
		List<StudentRegistration> studentRegs = studentRegService.findRegistrationByidcourse(theId);
		theModel.addAttribute("studentRegs",studentRegs);
		return "StudentRegs/student-list";
	}
	
	@RequestMapping("/showFormForUpdate")
	public String ShowFormForUpdate(@RequestParam("IdCourse") int theId,Model theModel){
		
		Course theCourse = CourseService.findCoureseByidcourse(theId);
		theModel.addAttribute("theCourse",theCourse);
		
		return "Course/Course-Form";
	}
	
	
	@RequestMapping("/Delete")
	public String delete(@RequestParam("IdCourse") int id) {
		
		CourseService.delete(id);
		
		return "redirect:/Course/course-list";
	}
	
	
	@RequestMapping("/showFormForAddCourse")
	public String showFromForAdd( Model theModel) {
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName(); // holds the name of logIn 
		Course theCourse = new Course(currentPrincipalName);
		theModel.addAttribute("theCourse",theCourse);
		
		return "Course/Course-Form";
	}
	
	@RequestMapping("/save")
	public String saveCourse(@ModelAttribute("Course") Course theCourse, Model theModel) {
		
		// save the employee
		CourseService.save(theCourse);
		
		// use a redirect to prevent duplicate submissions
		return "redirect:/Course/course-list";
	}
	
	@RequestMapping("/addStudent")
	public String addStudent(@ModelAttribute("StudenRegistration") StudentRegistration theStudentReg, Model theModel) {
		
		StudentRegistration SReg = new StudentRegistration(theStudentReg.getIdcourse());
		theModel.addAttribute("theStudentReg",SReg);
		//studentRegService.update(theStudentReg);
		
		return "StudentRegs/AddStudent";
	}
	
	@RequestMapping("addStudent/save")
	public String saveCourse(@ModelAttribute("StudenRegistration") StudentRegistration theStudentReg, Model theModel) {
		
		// save the employee
		studentRegService.update(theStudentReg);

		
		// use a redirect to prevent duplicate submissions
		return "redirect:/Course/course-list";
	}
		
	
	@RequestMapping("/ShowStudentRegistration/Update")
	public String UpdateStudentRegistration(@RequestParam("studentid") int studentid ,Model theModel) {
		
		StudentRegistration theStudentReg = studentRegService.findRegistrationBystudentid(studentid);
		theModel.addAttribute("theStudentReg",theStudentReg);
		
		return "StudentRegs/student-Form";
	}
	
	@RequestMapping("/ShowStudentRegistration/save")
	public String saveStudentReg(@ModelAttribute("StudenRegistration") StudentRegistration theStudentReg, Model theModel) {
		
		// save the employee
		studentRegService.save(theStudentReg);
		
		// use a redirect to prevent duplicate submissions
		return "redirect:/Course/ShowStudentRegistration" + "?idcourse="+theStudentReg.getIdcourse();
	}
	
	@RequestMapping("/ShowStudentRegistration/Delete")
	public String deleteReg(@ModelAttribute("StudenRegistration") StudentRegistration theStudentReg, Model theModel) {
		
		studentRegService.delete(theStudentReg.getStudentid());
		
		return "redirect:/Course/ShowStudentRegistration" + "?idcourse="+theStudentReg.getIdcourse();
	}
	
	
	//ADD GRADES 
	@RequestMapping("/ShowStudentRegistration/AddGrade")
	public String AddGrade(@RequestParam("studentid") int studentid ,Model theModel) {
		
		
		StudentRegistration theStudentReg = studentRegService.findRegistrationBystudentid(studentid);
		theModel.addAttribute("theStudentReg",theStudentReg);
		
		return "/StudentRegs/addGrade";	
	}
	
	@RequestMapping("/ShowStudentRegistration/saveGrade")
	public String SaveGrade(@ModelAttribute("StudenRegistration") StudentRegistration theStudentReg, Model theModel)
	{
		
		studentRegService.save(theStudentReg);
		return "redirect:/Course/ShowStudentRegistration" + "?idcourse="+theStudentReg.getIdcourse();
	}
	
}
