package myy803.course_mgt_app.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.User.UserBuilder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/*
 * @Configuration Indicates that a class declares one or more 
 * @Bean methods and may be processed by the 
 * Spring container to generate bean definitions 
 * and service requests for those beans at runtime. 
 * The class may also have code that configures other 
 * spring functionalities. 
 */
@Configuration
@EnableWebSecurity
public class ApplicationSecurityConfig extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {

		
		// bcrypt online https://bcrypt-generator.com/
		
		// password "zarras" is externally encrypted to the following
		UserDetails user1 = User.withUsername("zarras")
			     .password("$2a$12$ORbomLSKIv9L/oZRXlhF9u0gCQ842f3RQi6PsCXLky56rJlVt9vkq")
			     .roles("ADMIN")
			     .build();
		
		// password "pvassil" is externally encrypted to the following
		UserDetails user2 = User.withUsername("pvassil")
			     .password("$2a$12$pQlaLUuZC3xxeH.1oMo2uOyBDMXOC/ES7d.lGv/bivfilQKShQ/o6")
			     .roles("ADMIN")
			     .build();
		
		auth.inMemoryAuthentication().withUser(user1).withUser(user2);
		
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}	
}







