package myy803.course_mgt_app.entity;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;




@Entity
@Table(name="course")
public class Course{
	
	//define fields
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id ;
	
	@Column(name="name")
	private String name;
	
	@Column(name="syllabus")
	private String syllabus;
	
	@Column(name="year")
	private int year;
	
	@Column(name="semester")
	private int semester;
	
	@Column(name="instructor")
	private String instructor;
	
	@OneToMany(targetEntity=StudentRegistration.class, mappedBy="idcourse", fetch=FetchType.EAGER) 
	private List<StudentRegistration> listOfStudent;
	
	
	//Constructors 
	public Course() {
		super();
	}
		
	public Course(int id, String name, String syllabus , int year , int semester,String instructor) {
		this.setId(id);
		this.setName(name);
		this.setSyllabus(syllabus);
		this.setYear(year);
		this.setSemester(semester);
		this.instructor=instructor;
	}
	
	public Course(int id , String name , int semester ) {
		this.setId(id);
		this.setName(name);
		this.setSemester(semester);
	}
	
	public Course(String instructor) {
		this.instructor=instructor;
		//this.setListregistrations(listRegistration) ;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSyllabus() {
		return syllabus;
	}

	public void setSyllabus(String syllabus) {
		this.syllabus = syllabus;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getSemester() {
		return semester;
	}

	public void setSemester(int semester) {
		this.semester = semester;
	}
	
	public String getInstructor() {
		return instructor;
	}

	public void setInstructor(String instructor) {
		this.instructor = instructor;
	}
	
	
	public List<StudentRegistration> getListOfStudent() {
		return listOfStudent;
	}

	public void setListOfStudent(List<StudentRegistration> listOfStudent) {
		this.listOfStudent = listOfStudent;
	}
	
	// define toString
	@Override
	public String toString() {
		return "COURSE [id=" + id + ", name=" + name + ", instructor=" + instructor +  "]";
	}
	
}