package myy803.course_mgt_app.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_regs")
public class StudentRegistration {

		//define fields
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		@Column(name="studentid")
		private int studentid;

		@Column(name="idcourse")	
		private int idcourse ;
		
		@Column(name="name")
		private String name;
		
		@Column(name="yearofregistration")
		private int yearofregistration;
		
		@Column(name="grade")
		private int grade;
		
		@Column(name = "projectgrade")
		private int projectgrade;
		
		
		//Constructors 
		public StudentRegistration() {}	
		
		public StudentRegistration(int idcourse) {
			this.idcourse =idcourse;
		}
		
		public StudentRegistration(int idcourse , String name , int yearofregistration ,int studentid) {
			this.setIdcourse(idcourse);
			this.name=name;
			this.setYearofregistration(yearofregistration);
			this.setStudentid(studentid);
		}

		public int getIdcourse() {
			return idcourse;
		}

		public void setIdcourse(int idcourse) {
			this.idcourse = idcourse;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public int getYearofregistration() {
			return yearofregistration;
		}

		public void setYearofregistration(int yearofregistration) {
			this.yearofregistration = yearofregistration;
		}
		
		public int getStudentid() {
			return studentid;
		}

		public void setStudentid(int studentid) {
			this.studentid = studentid;
		}	
		
		
		public int getGrade() {
			if( grade > 10 | grade< 0 )
			{
				this.grade = 0 ;
				System.out.println("invalid number grade");
			}
			//if(! Character.isDigit(grade))
			//{
			//	System.out.println("invalid number");
			//	this.grade = 0 ;
			//}
			return grade;
		}
		
		public void setGrade(int grade) {
			this.grade = grade;
		}
		
		
		public int getProjectgrade() {
			
			if(projectgrade >10 | projectgrade<0)
			{
				this.projectgrade = 0; 
				System.out.println("invalid number grade for project");
			}
			return projectgrade;
		}

		public void setProjectgrade(int projectgrade) {
			this.projectgrade = projectgrade;
		}

		//toString
		@Override
		public String toString() {
			return "student [id=" + idcourse + ", name=" + name + ",yearofregistration =" + yearofregistration + ",grade =" + grade + "]";
		}

}
